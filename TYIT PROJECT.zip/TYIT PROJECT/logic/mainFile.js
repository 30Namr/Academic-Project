function getBotResponse(input) {
    //Navigation Responses
    if (input == "1") {
        setTimeout(() => {
            location.href = "./ViewStock.php"
          }, 1000);
        return "Taking you to View Stock Page";
    } else if (input == "2") {
        setTimeout(() => {
            location.href = "./#otherSerives"
          }, 2000);
        return "Taking you to Insurance Guide Section";
    } else if (input == "3") {
        setTimeout(() => {
            location.href = "./#otherSerives"
          }, 2000);
        return "Taking you to Finance Guide Section";
    } else if (input == "4") {
        setTimeout(() => {
            location.href = "./#otherSerives"
          }, 2000);
        return "Taking you to RTO Transfer Section";
    } else if (input == "5") {
        setTimeout(() => {
            location.href = "./sellYourCar.php"
          }, 2000);
        return "Taking you to Sell your Car Page";
    } else if (input == "6") {
        setTimeout(() => {
            location.href = "./ContactUs.php#Feedbackbot"
          }, 2000);
        return "Taking you to Feedback Section";
    }

    // Simple responses
    if (input == "Hii!") {
        return "Hello there!";
    } else if (input == "Goodbye") {
        return "Talk to you later!";
    } else {
        return "Please enter the appropriate number!";
    }
}