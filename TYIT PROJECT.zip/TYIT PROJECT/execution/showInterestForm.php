<?php
    include_once "../config/dbconnect.php";
    
    if(isset($_POST['submit']))
    {
        $CarName = $_POST['car_name'];
        $CarModel = $_POST['car_model'];
        $Year = $_POST['year'];
        $Price = $_POST['price'];
        $FName = $_POST['fname'];
        $PhoneNo = $_POST['phone_no'];

        $Insert = mysqli_query($conn,"INSERT INTO `show_interest`(`full_name`, `contact_no`, `car_name`, `car_model`, `car_year`, `car_price`) VALUES ('$FName','$PhoneNo','$CarName','$CarModel','$Year','$Price')");
        
        if($Insert) {
            echo "<script>alert('Your Details Saved Successfully, Owner Will Contact You As Soon As Possible!!.');document.location='../ViewStock.php'</script>";
        } else {
            echo mysqli_error($conn);
        }        
    }        
?>