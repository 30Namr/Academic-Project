<?php
    include_once "../config/dbconnect.php";
    
    if(isset($_POST['submit']))
    {
        $sellBrand = $_POST['s_brand'];
        $SellCarName = $_POST['s_carname'];
        $SellYear = $_POST['s_year'];
        $SellModel = $_POST['s_model'];
        $SellFuel = $_POST['s_fuel'];
        $SellKiloMeter = $_POST['s_kiloDriven'];
        $SellTrans = $_POST['s_transmission'];
        $SellName = $_POST['s_name'];
        $SellPhoneNo = $_POST['s_number'];

        $Insert = mysqli_query($conn,"INSERT INTO `sell_your_car`(`full_name`, `contact_no`, `brand_name`, `year`, `model_name`, `fuel_type`, `kilo_driven`, `transmission`) VALUES ('$SellName','$SellPhoneNo','$sellBrand','$SellYear','$SellModel','$SellFuel','$SellKiloMeter','$SellTrans')");
        
        if($Insert) {
            echo "<script>alert('Your Details Saved Successfully, Owner Will Contact You As Soon As Possible!!.');document.location='../sellYourCar.php'</script>";
        } else {
            echo mysqli_error($conn);
        }        
    }        
?>