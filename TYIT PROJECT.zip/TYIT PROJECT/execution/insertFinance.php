<?php
    include_once "../config/dbconnect.php";
    
    if(isset($_POST['submit']))
    {
        $FName = $_POST['fname'];
        $ContactNo = $_POST['contactno'];
        $Price = $_POST['price'];

        $Insert = mysqli_query($conn,"INSERT INTO `finance_guide`(`full_name`, `contact_no`, `estimated_price`) VALUES ('$FName','$ContactNo','$Price')");
        
        if($Insert) {
            echo "<script>alert('For Finance Guide, Details Provided By You Are Successfully Recorded.');document.location='../index.php#otherSerives'</script>";
        } else {
            echo mysqli_error($conn);
        }        
    }
        
?>