<?php
    include_once "../config/dbconnect.php";
    
    if(isset($_POST['submit']))
    {
        $FDName = $_POST['fd_name'];
        $FDOpinion = $_POST['fd_opinion'];
        $Star = $_POST['star'];

        $Insert = mysqli_query($conn,"INSERT INTO `feedback`(`full_name`, `opinion`, `rated_us`) VALUES ('$FDName','$FDOpinion','$Star')");
        
        if($Insert) {
            echo "<script>alert('Dear User, Your Feedback Saved Successfully.');document.location='../ContactUs.php'</script>";
        } else {
            echo mysqli_error($conn);
        }        
    }        
?>