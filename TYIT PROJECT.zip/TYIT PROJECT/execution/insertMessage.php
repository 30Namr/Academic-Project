<?php
    include_once "../config/dbconnect.php";
    
    if(isset($_POST['submit']))
    {
        $FName = $_POST['first_name'];
        $Email = $_POST['email'];
        $PhoneNo = $_POST['phoneno'];
        $Message = $_POST['report'];

        $Insert = mysqli_query($conn,"INSERT INTO `message`(`full_name`, `email_id`, `contact_no`, `message`) VALUES ('$FName','$Email','$PhoneNo','$Message')");
        
        if($Insert) {
            echo "<script>alert('Message Saved Successfully.');document.location='../ContactUs.php'</script>";
        } else {
            echo mysqli_error($conn);
        }        
    }        
?>