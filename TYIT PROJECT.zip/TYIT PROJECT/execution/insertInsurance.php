<?php
    include_once "../config/dbconnect.php";
    
    if(isset($_POST['submit']))
    {
        $FullName = $_POST['fullname'];
        $ContactNo = $_POST['mobileno'];
        $VehicleNo = $_POST['vehicleno'];

        $Insert = mysqli_query($conn,"INSERT INTO `insurance_guide`(`full_name`, `contact_no`, `vehicle_no`) VALUES ('$FullName','$ContactNo','$VehicleNo')");
        
        if($Insert) {
            echo "<script>alert('For Insurance Guide, Details Provided By You Are Successfully Recorded.');document.location='../index.php#otherSerives'</script>";
        } else {
            echo mysqli_error($conn);
        }        
    }
        
?>