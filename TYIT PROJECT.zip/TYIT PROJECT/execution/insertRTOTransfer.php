<?php
    include_once "../config/dbconnect.php";
    
    if(isset($_POST['submit']))
    {
        $FullName = $_POST['fullnames'];
        $ContactNo = $_POST['contactnos'];
        $VehicleNo = $_POST['vehiclenos'];

        $Insert = mysqli_query($conn,"INSERT INTO `rto_transfer`(`full_name`, `contact_no`, `vehicle_no`) VALUES ('$FullName','$ContactNo','$VehicleNo')");
        
        if($Insert) {
            echo "<script>alert('For RTO Transfer, Details Provided By You Are Successfully Recorded.');document.location='../index.php#otherSerives'</script>";
        } else {
            echo mysqli_error($conn);
        }        
    }
        
?>