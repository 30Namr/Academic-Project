<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sainath Motors Website</title>

    <!--======== main css file link ========= -->
    <link rel="stylesheet" href="./websiteDesign/mainFile.css">
    <!--------css-------- bootstrap link ------------------>
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <!---------js------- bootstrap link ------------------>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!------ Font Awesome CDNJS -------->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <!--  testmonial -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">

    <!-- chatbot  -->
    <link rel="stylesheet" href="./websiteDesign/chatbot.css">

    <style>
        html {
            scroll-behavior: smooth;
            font-family: Helvetica, sans-serif, Arial;
        }

        body {
            margin: 0 auto;
        }
    </style>
</head>

<body>

    <!-- Header Secton Started -->
    <header>
        <nav class="navbar navbar-expand-sm bg-body-tertiary" data-bs-theme="dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="./index.php"><img src="./image/newlogo.png" alt=""
                        style="width: 220px;"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="./ViewStock.php">View Stock</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#otherSerives">Other Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./sellYourCar.php">Sell Your Car</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./aboutUs.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./ContactUs.php">Contact Us</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- Header Secton Ended -->
    <!-- CHAT BAR BLOCK -->
    <div class="chat-bar-collapsible">
        <button id="chat-button" type="button" class="collapsible">Need help?</button>

        <div class="content">
            <div class="full-chat-block">
                <!-- Message Container -->
                <div class="outer-container">
                    <div class="chat-container">
                        <!-- Messages -->
                        <div id="chatbox">
                            <h5 id="chat-timestamp"></h5>
                            <p id="botStarterMessage1" class="botText"><span>Loading...</span></p>
                            <p id="botStarterMessage2" class="botText"><span>Loading...</span></p>
                        </div>

                        <!-- User input box -->
                        <div class="chat-bar-input-block">
                            <div id="userInput">
                                <input id="textInput" class="input-box" type="text" name="msg"
                                    placeholder="Tap 'Enter' to send a message">
                                <p></p>
                            </div>

                            <div class="chat-bar-icons">
                                <i onclick="sendButton()" id="chat-icon" class="fa-solid fa-paper-plane"></i>


                            </div>
                        </div>

                        <div id="chat-bar-bottom">
                            <p></p>
                        </div>

                    </div>
                </div>

            </div>
        </div>

    </div>
    <!--1------- slider  home page start here--------->
    <section class="section1">
        <div id="carouselExample" class="carousel slide">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="./image/carousal1.jpeg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="./image/carousal2.jpeg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="./image/carousal3.jpeg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="./image/carousal4.jpeg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="./image/carousal5.jpeg" class="d-block w-100" alt="...">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>
    <!--------- slider  home page end here --------->


    <!----2----- section2 down  home page start here --------->
    <section class="section section-bg">
        <div class="container">
            <div class="section-title">
                <h1>WHY BUY FROM US</h1>
            </div>
            <div class="row animation_effect">

                <div class="col-xl-3 col-md-6 d-flex align-items-stretch">
                    <div class="service-card">
                        <div class="service-icon">
                            <img src="./image/whyBuyFromUS1.webp" alt="Fast financing" class="">
                        </div>
                        <h3 class="service-title">&nbsp;Financing Done Quickly</h3>

                        <p class="service-desc">Enjoy tranquilly as we quicken the approval of your car loan from banks.
                        </p>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 d-flex align-items-stretch">
                    <div class="service-card">
                        <div class="service-icon">
                            <img src="./image/WhyBuyFromUs2.webp" alt="delivered to you" class="">
                        </div>
                        <h3 class="service-title">Swift Handover of the Car</h3>

                        <p class="service-desc">At Sainath Motors, we will work hard to assist you so that you don't
                            have
                            to
                            wait
                            any longer
                            months to acquire the car of your dreams.</p>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 d-flex align-items-stretch">
                    <div class="service-card">
                        <div class="service-icon"> <img src="./image/WhyBuyFromUs.webp" class=" ">
                        </div>
                        <h3 class="service-title">Numerous Quality Checks</h3>
                        <p class="service-desc">We check our vehicles for a number of factors and prepare them for the
                            road
                            as if
                            they were
                            brand-new.</p>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 d-flex align-items-stretch">
                    <div class="service-card">
                        <div class="service-icon">
                            <img src="./image/WhyBuyFromUs4.webp" alt="100% refund" class="">
                        </div>
                        <h3 class="service-title">Broad Variety</h3>
                        <p class="service-desc"> We provide vehicles that are well adored by people and are widely known
                            on
                            the
                            road.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--------- section2 down  home page end here --------->


    <!--3------- section3 down  home page start here --------->
    <section class="section section-bg">
        <div class="container">
            <div class="section-title1">
                <h1>BUY IN 3 EASY STEPS</h1>
            </div>
            <div class="row">
                <div class="col-md-4 aditya ">
                    <div class="card-mb-4 ">
                        <img src="./image/section3.1.png" class="card-img-top">
                    </div>
                    <div class="card-body">
                        <div class="card-title">
                            <h3>Find the perfect car for you</h3>
                        </div>
                        <p class="card-text">Seamlessly browse all the available cars.</p>
                    </div>
                </div>

                <div class="col-md-4  aditya">
                    <div class="card-mb-4">
                        <img src="./image/section3.2.png" class="card-img-top">
                    </div>
                    <div class="card-body">
                        <div class="card-title">
                            <h3>Test Drive at our Showroom</h3>
                        </div>
                        <p class="card-text">Enjoy the convenience of a test drive for free.</p>
                    </div>
                </div>

                <div class="col-md-4 aditya">
                    <div class="card-mb-4">
                        <img src="./image/section3.3.png" class="card-img-top">
                    </div>
                    <div class="card-body">
                        <div class="card-title">
                            <h3>Buy it your way</h3>
                        </div>
                        <p class="card-text">You can pay in full or have it financed,the choice is yours.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--------- section3 down  home page end here --------->


    <!---4------ section4 down  home page end here --------->
    <section class="section section-bg" id="otherSerives">
        <div class="container">
            <div class="section-title2">
                <h1>OTHER SERVICES</h1>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="card" style="background: #f2f2f2;">
                        <img src="./image/OurServices1.webp" class="card-img-top">
                        <div class="card-body">
                            <h4 class="_4card-title">Insurance Guide</h4>
                            <p class="card-desc">Because there are so many insurance options on the market, many
                                consumers get
                                confused
                                and buy the inappropriate insurance. Here, Sainath Motors will assist you and get the
                                ideal insurance for your needs.</p>

                            <div id="firstpopup">
                                <button class="open-button" onclick="openForm()">Open Form</button>

                                <div class="form-popup" id="myForm">
                                    <form class="form-container" action="./execution/insertInsurance.php" method="POST">

                                        <label for="fname"><b>Full Name</b></label>
                                        <input type="text" placeholder="Enter Your Name" name="fullname" maxlength="40" required><br>

                                        <label for="mobile"><b>Contact Number</b></label>
                                        <input type="text" placeholder="Enter Mobile Number" name="mobileno" maxlength="10" required><br>


                                        <label for="vehicleno"><b>Your Vehicle Registration Number</b></label>
                                        <input type="text" placeholder="Enter Vehicle Registration Number" name="vehicleno" maxlength="12" required><br>

                                        <button type="submit" name="submit" class="btn">Submit</button><br>
                                        <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card" style="background:  #f2f2f2;">
                        <img src="./image/OurServices2.webp" class="card-img-top">
                        <div class="card-body">
                            <h4 class="_4card-title">Finance Guide</h4>
                            <p class="card-desc">Uncertain of your down payment and emi amounts for your ideal vehicle?
                                Sainath
                                Motors
                                will guide with this and can also help you get your loan approved by the specific bank.
                            </p>

                            <div id="secondFormpopup">
                                <button class="open-button" onclick="openForm1()">Open Form</button>

                                <div class="form-popup" id="myForm1">
                                    <form class="form-container" action="./execution/insertFinance.php" method="POST">

                                        <label for="fname"><b>Full Name</b></label>
                                        <input type="text" placeholder="Enter Your Full Name" name="fname" maxlength="40" required><br>

                                        <label for="contactno"><b>Contact Number</b></label>
                                        <input type="text" placeholder="Enter Contact Number" name="contactno" maxlength="10" required><br>

                                        <label for="price"><b> Your Estimated Price</b></label>
                                        <input type="text" placeholder="Enter Your Estimated Price" name="price" maxlength="12" required><br>

                                        <button type="submit" name="submit" class="btn">Submit</button><br>
                                        <button type="button" class="btn cancel" onclick="closeForm1()">Close</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card" style="background: #f2f2f2;">
                        <img src="./image/OurServices3.webp" class="card-img-top">
                        <div class="card-body">
                            <h4 class="_4card-title"> RTO Transfer</h4>
                            <p class="card-desc">It's crucial to update the car registration certificate with the name
                                of
                                the new
                                owner
                                after purchasing a used vehicle. We'll take care of this for you here so you won't
                                require a trip to the RTO.</p>

                            <div id="thirdformpopup">
                                <button class="open-button" onclick="openForm2()">Open Form</button>

                                <div class="form-popup" id="myForm2">
                                    <form class="form-container" action="./execution/insertRTOTransfer.php" method="POST">

                                        <label for="fname"><b>Full Name</b></label>
                                        <input type="text" placeholder="Enter Your Full Name" name="fullnames" maxlength="40" required><br>

                                        <label for="contactno"><b>Contact Number</b></label>
                                        <input type="text" placeholder="Enter Contact Number" name="contactnos" maxlength="10" required><br>

                                        <label for="vehicleno"><b>Your Vehicle Registration Number</b></label>
                                        <input type="text" placeholder="Enter Vehicle Registration Number" name="vehiclenos" maxlength="12" required><br>

                                        <button type="submit" name="submit" class="btn">Submit</button><br>
                                        <button type="button" class="btn cancel" onclick="closeForm2()">Close</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

    </section>
    <!--------- section4 down  home page end here --------->


    <!----5----- section5 down  home page start here --------->
    <section class="section1 section-bg">
        <div class="container">
            <div class="section-title3">
                <h1>FEATURED CARS</h1>
            </div>

            <div class="row">
            <?php
                include_once "./config/dbconnect.php";
                $sql="SELECT * FROM `car_stock` LIMIT 3";
                $result=$conn-> query($sql);
                if ($result-> num_rows > 0){
                    while ($row=$result-> fetch_assoc()) {
            ?>
                <div class="col-md-4 d-flex justify-content:between">
                    <div class="card_FeatureCard ">
                        <a href="./singlepage.php?carId=<?=$row['car_id']?>"><img height='200px' width='350px' class="card-img-top" src="data:image/jpeg;charset=utf8;base64,<?php echo base64_encode($row["car_image"]); ?>"></a>
                        <div class="card-body featurecarDetails ">
                            <h3 class="card-title"><?=$row["car_name"]?></h3>
                            <p class="card-text"><?=$row["car_model"]?> <span><?=$row["transmission"]?></span></p>
                            <div>
                                <li><?=$row["kilo_driven"]?>Km<span>|</span></li>
                                <li><?=$row["owner"]?><span>|</span></li>
                                <li><?=$row["fuel_type"]?></li>
                            </div>
                            <button type="button" class="btn _PriceBtn"><a href="./singlepage.php?carId=<?=$row['car_id']?>">&nbsp;&#x20B9&nbsp;<?=$row["price"]?></a>
                            </button>
                        </div>
                    </div>
                </div>
            <?php
                    }
                }
            ?>
            </div>

            <div id="SeeMore">
                <a class="btn btn-primary" href="./ViewStock.php" role="button">See More Cars</a>
            </div>
        </div>
    </section>
    <!--------- section5 down  home page end here --------->


    <!----6----- section6 down  home page start here --------->
    <section class="section section-bg">
        <div class="container1">
            <div class="_lsdiv">
                <h2>Selling a car? We’re buying!</h2>
                <p>Book an appointment for free car inspection and sell it instantly on the same day.</p>
                <div class="styling">
                    <a href="./sellYourCar.php">SEll YOUr Car</a>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <div class="image"><img src="./image/sellyourcarHome.png" style="width: 450px; height: 400px;"></div>
        </div>
    </section>
    <!--------- section6 down  home page end here --------->


    <!----7----- section7 down  home page start here --------->
    <section class="review section ">
        <div class="container">
            <div class="section-title4">
                <h1>TESTIMONIAL</h1>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div id="testimonial-slider" class="owl-carousel">
                        <div class="testimonial">
                            <div class="pic">
                                <img src="./image/reviewsPic.gif">
                            </div>
                            <div class="testimonial-profile">
                                <h3 class="title"> Satish Palkar</h3>
                                <span class="post"></span>
                            </div>
                            <p class="description">
                                "Best car sells in this sainath motors."
                            </p>
                        </div>
                        <div class="testimonial">
                            <div class="pic">
                                <img src="./image/reviewsPic.gif">
                            </div>
                            <div class="testimonial-profile">
                                <h3 class="title">Vivek Ramachandran</h3>
                                <span class="post"></span>
                            </div>
                            <p class="description">
                                "A very trustworthy place and good people to deal with. Happy to have them while dealing
                                with Cars and managing its services!!!."
                            </p>
                        </div>
                        <div class="testimonial">
                            <div class="pic">
                                <img src="./image/reviewsPic.gif">
                            </div>
                            <div class="testimonial-profile">
                                <h3 class="title">Manish Vengurlekar</h3>
                                <span class="post"></span>
                            </div>
                            <p class="description">
                                "If u are looking for quality pre-owned car with peaceful transaction do visit once.
                                Very nice cars and proper​ service.."
                            </p>
                        </div>
                        <div class="testimonial">
                            <div class="pic">
                                <img src="./image/reviewsPic.gif">
                            </div>
                            <div class="testimonial-profile">
                                <h3 class="title"> Abhijeet Jagdale</h3>
                                <span class="post">Local Guide</span>
                            </div>
                            <p class="description">
                                "Proffessional people. can deal with them no issues."
                            </p>
                        </div>
                        <div class="testimonial">
                            <div class="pic">
                                <img src="./image/reviewsPic.gif">
                            </div>
                            <div class="testimonial-profile">
                                <h3 class="title">YASHAWANT SANE</h3>
                                <span class="post"></span>
                            </div>
                            <p class="description">
                                "reliable car deal."
                            </p>
                        </div>
                        <div class="testimonial">
                            <div class="pic">
                                <img src="./image/reviewsPic.gif">
                            </div>
                            <div class="testimonial-profile">
                                <h3 class="title"> Ankur Sorathiya</h3>
                                <span class="post"></span>
                            </div>
                            <p class="description">
                                "V. Good."
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!----7----- section7 down  home page end here --------->

    <!---8------ section8 down  home page start  here --------->

    <!--------- section8 down home page end here --------->


    <!--------- footeer down  home page start here --------->
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <a href="index.php">
                        <img src="./image/weblogo-removebg-preview.png" alt="Sainath Motors" class="card-img-top"
                            style="width: 100px;">
                        <h1 class="card-title">Sainath Motors</h1>
                    </a>
                    <br>
                    <p class="card-text"> Your dream car may be purchased from Sainath Motors for the finest value and
                        quality. We have tens of thousands of happy consumers, and that number is rising daily. Join our
                        Sainath Motors family and take pleasure in the calm that comes with owning a flawless vehicle.
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3">
                    <h5 class="card-title">UseFul Link</h5>
                    <ul>
                        <li><a href="./index.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Home</span></a>
                        </li><br>
                        <li><a href="#otherSerives"> <i class="fa-solid fa-angles-right"></i>
                                <span>Our Services</span></a>
                        </li><br>
                        <li> <a href="./ViewStock.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>View Stock</span></a>
                        </li><br>
                        <li><a href="./sellYourCar.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Sell Your Car</span></a>
                        </li><br>
                        <li><a href="./aboutUs.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>About Us</span></a>
                        </li><br>
                        <li> <a href="./ContactUs.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Contact Us</span></a>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Popular Cities</h5>
                    <ul style="margin-left: 25px;">
                        <li>Mumbai</li><br>
                        <li>Pune</li><br>
                        <li>Raigad</li><br>
                        <li>Mahad</li><br>
                        <li>Mangoan</li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Popular Brands</h5>
                    <ul style="margin-left: 25px;">
                        <li>Maruti Suzuki</li><br>
                        <li>Tata</li><br>
                        <li>Hyundai</li><br>
                        <li>Honda</li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Address / Contact Us</h5>
                    <p class="card-text"> <i class="fa-solid fa-location-dot"></i>
                        Shop No.10, Building
                        No.3, Phase -1 Neelam Nagar,
                        Mulund East Mumbai,
                        Maharashtra 400081
                        India</p>
                    <p class="card-text"><i class="fa-solid fa-phone"></i> +91 90904500112 </p>
                    <p class="card-text"><i class="fa-solid fa-envelope"></i> sainathmotors@gmail.com</p>
                </div>
            </div>
            <section id="copy-right">
                <div class="copy-right-sec"><i class="fa-solid fa-copyright"></i>
                    2023 <a href="index.php"> <span>Sainath Motors</span> </a>
                </div>
            </section>
        </div>
    </footer>
    <!--------- footeer down  home page end here --------->


    <!--================== javascript File main file link ======-->
    <script type="text/javascript" src="./logic/mainFile.js"></script>

    <script>
        function openForm() {
            document.getElementById("myForm").style.display = "inline";
        }
        function closeForm() {
            document.getElementById("myForm").style.display = "none";
        }
        function openForm1() {
            document.getElementById("myForm1").style.display = "block";
        }
        function closeForm1() {
            document.getElementById("myForm1").style.display = "none";
        }
        function openForm2() {
            document.getElementById("myForm2").style.display = "inline-block";
        }
        function closeForm2() {
            document.getElementById("myForm2").style.display = "none";
        }
    </script>

    <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
    <script>

        $(document).ready(function () {
            $("#testimonial-slider").owlCarousel({
                items: 2,
                itemsDesktop: [1000, 2],
                itemsDesktopSmall: [979, 2],
                itemsTablet: [768, 1],
                pagination: false,
                navigation: true,
                navigationText: ["", ""],
                autoPlay: true
            });
        });
    </script>

    <!-- chatbot -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
    <script>
        // Collapsible
        var coll = document.getElementsByClassName("collapsible");

        for (let i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function () {
                this.classList.toggle("active");

                var content = this.nextElementSibling;

                if (content.style.maxHeight) {
                    content.style.maxHeight = null;
                } else {
                    content.style.maxHeight = content.scrollHeight + "px";
                }

            });
        }

        function getTime() {
            let today = new Date();
            hours = today.getHours();
            minutes = today.getMinutes();

            if (hours < 10) {
                hours = "0" + hours;
            }

            if (minutes < 10) {
                minutes = "0" + minutes;
            }

            let time = hours + ":" + minutes;
            return time;
        }

        // Gets the first message
        function firstBotMessage() {
            let firstMessage = "Hello there! I'm Autoamy."
            let secondMessage = "What can I help you with?<br>(Enter the appropriate task/service NUMBER that you intend to avail.) <br>1. View available stock <br>2. Ask for Insurance Guidance <br>3. Ask for Finance Guidance <br>4. RTO Transfer <br>5. Sell your Car <br>6. Give Feedback"
            document.getElementById("botStarterMessage1").innerHTML = '<p class="botText"><span>' + firstMessage + '</span></p>';
            document.getElementById("botStarterMessage2").innerHTML = '<p class="botText"><span>' + secondMessage + '</span></p>';

            let time = getTime();

            $("#chat-timestamp").append(time);
            document.getElementById("userInput").scrollIntoView(false);
        }

        firstBotMessage();

        // Retrieves the response
        function getHardResponse(userText) {
            let botResponse = getBotResponse(userText);
            let botHtml = '<p class="botText"><span>' + botResponse + '</span></p>';
            $("#chatbox").append(botHtml);

            document.getElementById("chat-bar-bottom").scrollIntoView(true);
        }

        //Gets the text text from the input box and processes it
        function getResponse() {
            let userText = $("#textInput").val();

            if (userText == "") {
                userText = "Hi!";
            }

            let userHtml = '<p class="userText"><span>' + userText + '</span></p>';

            $("#textInput").val("");
            $("#chatbox").append(userHtml);
            document.getElementById("chat-bar-bottom").scrollIntoView(true);

            setTimeout(() => {
                getHardResponse(userText);
            }, 1000)

        }

        // Handles sending text via button clicks
        function buttonSendText(sampleText) {
            let userHtml = '<p class="userText"><span>' + sampleText + '</span></p>';

            $("#textInput").val("");
            $("#chatbox").append(userHtml);
            document.getElementById("chat-bar-bottom").scrollIntoView(true);

            //Uncomment this if you want the bot to respond to this buttonSendText event
            // setTimeout(() => {
            //     getHardResponse(sampleText);
            // }, 1000)
        }

        function sendButton() {
            getResponse();
        }

        // Press enter to send a message
        $("#textInput").keypress(function (e) {
            if (e.which == 13) {
                getResponse();
            }
        });
    </script>



</body>

</html>