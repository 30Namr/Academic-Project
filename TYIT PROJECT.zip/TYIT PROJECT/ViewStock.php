<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ViewStock Page</title>
    <link rel="stylesheet" href="./websiteDesign/viewStock.css">

    <!--------css-------- bootstrap link ------------------>
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <!---------js------- bootstrap link ------------------>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!------ Font Awesome CDNJS -------->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <!-- filter -->

    <!-- chatbot  -->
    <link rel="stylesheet" href="./websiteDesign/chatbot.css">

    <style>
        html {
            scroll-behavior: smooth;
            font-family: Helvetica, sans-serif, Arial;
        }

        body {
            margin: 0 auto;
        }

        .col-md-4 {
            width: 33%;
        }
    </style>
</head>

<body>
    <!-- Header Secton Started -->
    <header>
        <nav class="navbar navbar-expand-sm bg-body-tertiary" data-bs-theme="dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="./index.php"><img src="./image/newlogo.png" alt=""
                        style="width: 220px;"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="./index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./sellYourCar.php">SELL YOUR CAR</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./aboutUs.php">ABOUT US</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./ContactUs.php">CONTACT US</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- CHAT BAR BLOCK -->
    <div class="chat-bar-collapsible">
        <button id="chat-button" type="button" class="collapsible">Need help?</button>

        <div class="content">
            <div class="full-chat-block">
                <!-- Message Container -->
                <div class="outer-container">
                    <div class="chat-container">
                        <!-- Messages -->
                        <div id="chatbox">
                            <h5 id="chat-timestamp"></h5>
                            <p id="botStarterMessage1" class="botText"><span>Loading...</span></p>
                            <p id="botStarterMessage2" class="botText"><span>Loading...</span></p>
                        </div>

                        <!-- User input box -->
                        <div class="chat-bar-input-block">
                            <div id="userInput">
                                <input id="textInput" class="input-box" type="text" name="msg"
                                    placeholder="Tap 'Enter' to send a message">
                                <p></p>
                            </div>

                            <div class="chat-bar-icons">
                                <i onclick="sendButton()" id="chat-icon" class="fa-solid fa-paper-plane"></i>

                            </div>
                        </div>

                        <div id="chat-bar-bottom">
                            <p></p>
                        </div>

                    </div>
                </div>

            </div>
        </div>

    </div>
    <!-- -------------------------------------------------------- -->

    <div class="container text-center">
        <div class="row">
        
          
    <div class="col-md-4 ">
    <div class="card non">
        <h4 class="card-title">Filter</h4>
        <a href="./ViewStock.php"><b>Clear Filters</b></a>
    </div>
            <div class="card filter">
                

                <div class="card-body">
                    <form action="" method="GET">
                        <div class="row">
                            <h5 class="namrata">Brand Filter</h5>
                            <div class="reddy">
                                <label for="" class="aashish">Brand</label> 
                                <select name="car_brands" style="border: 1px solid #b4afaf; border-radius: 2px;" class="phone">
                                    <option disabled selected>Select Brand</option>
                                    <option value="Maruti Suzuki">Maruti Suzuki</option>
                                    <option value="Hyundai">Hyundai</option>
                                    <option value="Tata">Tata</option>
                                    <option value="Mahindra">Mahindra</option>
                                    <option value="Toyota">Toyota</option>
                                    <option value="Honda">Honda</option>
                                    <option value="Volkswagen">Volkswagen</option>
                                </select>
                            </div>
                            <div>
                                <button type="submit" class="btn btn-primary lovepreet px-4" style="margin: 10px 0 0 0;">Filter</button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="card-body">
                    <form action="" method="GET">
                        <div class="row">
                            <h5 class="namrata">Kilometer Filter</h5>
                            <div class="reddy">
                                <label for="" class="redysir">Min KMs:</label>
                                <input class="ram" type="text" name="min_kms" value="<?php if(isset($_GET['min_kms'])){ echo $_GET['min_kms']; } else{ echo "1000"; }?>" maxlength="6" required class="form-control">
                            </div>
                            <div>
                                <label for="" class="redysir">Max KMs:</label>
                                <input class="ram" type="text" name="max_kms" value="<?php if(isset($_GET['max_kms'])){ echo $_GET['max_kms']; } else{ echo "100000"; }?>" maxlength="6" required class="form-control">
                            </div>
                            <div>
                                <button type="submit" class="btn btn-primary lovepreet  px-4" style="margin: 10px 0 0 0;">Filter</button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="card-body">
                    <form action="" method="GET">
                        <div class="row">
                            <h5 class="namrata">Price Filter</h5>
                            <div class="reddy">
                                <label for="" class="redysir">Min Price:</label>
                                <input class="ram"  type="text" name="start_price" value="<?php if(isset($_GET['start_price'])){ echo $_GET['start_price']; } else{ echo "250000"; }?>" maxlength="7" required class="form-control">
                            </div>
                            <div>
                                <label for="" class="redysir">Max Price:</label>
                                <input class="ram" type="text" name="end_price" value="<?php if(isset($_GET['end_price'])){ echo $_GET['end_price']; } else{ echo "2500000"; }?>" maxlength="8" required class="form-control">
                            </div>
                            <div>
                                <button type="submit" class="btn btn-primary lovepreet px-4" style="margin: 10px 0 0 0;">Filter</button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="card-body">
                    <form action="" method="GET">
                        <div class="row">
                            <h5 class="namrata">Transmission Filter</h5>
                            <div class="reddy">
                                <label for="" class="redysir">Transmission</label> <br>
                                <select class="namo" name="transmission" style="border: 1px solid #b4afaf; border-radius: 2px;">
                                    <option disabled selected>Select Transmission</option>
                                    <option value="Manual">Manual</option>
                                    <option value="Automatic">Automatic</option>
                                </select>
                            </div>
                            <div>
                                <button type="submit" class="btn btn-primary lovepreet px-4" style="margin: 10px 0 0 0;">Filter</button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="card-body">
                    <form action="" method="GET">
                        <div class="row">
                            <h5 class="namrata">Fuel Type Filter</h5>
                            <div  class="reddy">
                                <label for="" class="redysir">Fuel Type</label> <br>
                                <select class="namo"   name="fuel_type" style="border: 1px solid #b4afaf; border-radius: 2px;">
                                    <option disabled selected>Select Fuel Type</option>
                                    <option value="Petrol">Petrol</option>
                                    <option value="CNG">CNG</option>
                                    <option value="Diesel">Diesel</option>
                                </select>
                            </div>
                            <div>
                                <button type="submit" class="btn btn-primary lovepreet  px-4" style="margin: 10px 0 0 0;">Filter</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
            </div>
           

            <div class="col harshit">
                    <div class="card-body">
                        <div class="row">
                        <?php
                            include_once "./config/dbconnect.php";

                            if(isset($_GET['car_brands'])) {
                                $CarBrand = $_GET['car_brands'];
                                $sql="SELECT * FROM `car_stock`, `brand` WHERE car_stock.brand_id=brand.brand_id AND `brand_name` = '$CarBrand'";

                            } elseif(isset($_GET['min_kms']) && isset($_GET['max_kms'])) {
                                $MinKiloMeter = $_GET['min_kms'];
                                $MaxKiloMeter = $_GET['max_kms'];
                                $sql="SELECT * FROM `car_stock` WHERE `kilo_driven` BETWEEN $MinKiloMeter AND $MaxKiloMeter";

                            } elseif(isset($_GET['start_price']) && isset($_GET['end_price'])) {
                                $StartPrice = $_GET['start_price'];
                                $EndPrice = $_GET['end_price'];
                                $sql="SELECT * FROM `car_stock` WHERE `price` BETWEEN $StartPrice AND $EndPrice";

                            } elseif(isset($_GET['transmission'])) {
                                $Transmission = $_GET['transmission'];
                                $sql="SELECT * FROM `car_stock` WHERE `transmission` = '$Transmission'";

                            } elseif(isset($_GET['fuel_type'])) {
                                $FuelType = $_GET['fuel_type'];
                                $sql="SELECT * FROM `car_stock` WHERE `fuel_type` = '$FuelType'";

                            } else {
                                $sql="SELECT * FROM `car_stock`";
                            }

                            $result=$conn-> query($sql);
                            if ($result-> num_rows > 0){
                                while ($row=$result-> fetch_assoc()) {
                        ?>
                            <div class="col-md-4 d-flex">
                                <div class="card_FeatureCard ">
                                    <a href="./singlepage.php?carId=<?=$row['car_id']?>">
                                        <img height='150px' width='300px' class="card-img-top" alt="CarDetailsFromDB" src="data:image/jpeg;charset=utf8;base64,<?=base64_encode($row["car_image"])?>">
                                    </a>
                                    <div class="card-body featurecarDetails ">
                                        <h3 class="card-title"><?=$row["car_name"]?></h3>
                                        <p class="card-text"><?=$row["car_model"]?>&nbsp;<span><?=$row["transmission"]?></span></p>
                                        <div>
                                            <li><?=$row["kilo_driven"]?>Km<span>|</span></li>
                                            <li><?=$row["owner"]?><span>|</span></li>
                                            <li><?=$row["fuel_type"]?></li>
                                        </div>
                                        <button type="button" class="btn _PriceBtn"><a href="./singlepage.php?carId=<?=$row['car_id']?>">&nbsp;&#x20B9&nbsp;<?=$row["price"]?></a></button>
                                    </div>
                                </div>
                            </div>
                        <?php
                                }
                            }
                        ?>
                        </div>
              
                </div>
            </div>
        </div>
    </div>

    <!--------- footeer down  home page start here --------->
    <footer id="footer ">
        <div class="container reveal">
            <div class="row">
                <div class="col-md-6">
                    <a href="index.php">
                        <img src="./image/weblogo-removebg-preview.png" alt="Sainath Motors" class="card-img-top"
                            style="width: 100px;">
                        <h1 class="card-title">Sainath Motors</h1>
                    </a>
                    <br>
                    <p class="card-text"> Your dream car may be purchased from Sainath Motors for the finest value and
                        quality. We have tens of thousands of happy consumers, and that number is rising daily. Join our
                        Sainath Motors family and take pleasure in the calm that comes with owning a flawless vehicle.
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3">
                    <h5 class="card-title">UseFul Link</h5>
                    <ul>
                        <li><a href="index.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Home</span></a>
                        </li><br>
                        <li><a href="#Our Services"> <i class="fa-solid fa-angles-right"></i>
                                <span>Our Services</span></a>
                        </li><br>
                        <li> <a href="ViewStock.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>View Stock</span></a>
                        </li><br>
                        <li><a href="sellYourCar.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Sell Your Car</span></a>
                        </li><br>
                        <li><a href="aboutUs.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>About Us</span></a>
                        </li><br>
                        <li> <a href="ContactUs.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Contact Us</span></a>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Popular Cities</h5>
                    <ul style="margin-left: 30px;">
                        <li>Mumbai</li><br>
                        <li>Pune</li><br>
                        <li>Raigad</li><br>
                        <li>Mahad</li><br>
                        <li>Mangoan</li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Popular Brands</h5>
                    <ul style="margin-left: 30px;">
                        <li>Maruti Suzuki</li><br>
                        <li>Tata</li><br>
                        <li>Hyundai</li><br>
                        <li>Honda</li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Address / Contact Us</h5>
                    <p class="card-text"> <i class="fa-solid fa-location-dot"></i>
                        Shop No.10, Building
                        No.3, Phase -1 Neelam Nagar,
                        Mulund East Mumbai,
                        Maharashtra 400081
                        India</p>
                    <p class="card-text"><i class="fa-solid fa-phone"></i> +91 90904500112 </p>
                    <p class="card-text"><i class="fa-solid fa-envelope"></i> sainathmotors@gmail.com</p>
                </div>
            </div>
            <section id="copy-right">
                <div class="copy-right-sec"><i class="fa-solid fa-copyright"></i>
                    2023 <a href="index.php"> <span>Sainath Motors</span> </a>
                </div>
            </section>
        </div>
    </footer>
    <!--------- footeer down  home page end here --------->
    <script src="./logic/mainFile.js"></script>
    <!-- chatbot -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        // Collapsible
        var coll = document.getElementsByClassName("collapsible");

        for (let i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function () {
                this.classList.toggle("active");

                var content = this.nextElementSibling;

                if (content.style.maxHeight) {
                    content.style.maxHeight = null;
                } else {
                    content.style.maxHeight = content.scrollHeight + "px";
                }

            });
        }

        function getTime() {
            let today = new Date();
            hours = today.getHours();
            minutes = today.getMinutes();

            if (hours < 10) {
                hours = "0" + hours;
            }

            if (minutes < 10) {
                minutes = "0" + minutes;
            }

            let time = hours + ":" + minutes;
            return time;
        }

        // Gets the first message
        function firstBotMessage() {
            let firstMessage = "Hello there! I'm Autoamy."
            let secondMessage = "What can I help you with?<br>(Enter the appropriate task/service NUMBER that you intend to avail.) <br>1. View available stock <br>2. Ask for Insurance Guidance <br>3. Ask for Finance Guidance <br>4. RTO Transfer <br>5. Sell your Car <br>6. Give Feedback"
            document.getElementById("botStarterMessage1").innerHTML = '<p class="botText"><span>' + firstMessage + '</span></p>';
            document.getElementById("botStarterMessage2").innerHTML = '<p class="botText"><span>' + secondMessage + '</span></p>';

            let time = getTime();

            $("#chat-timestamp").append(time);
            document.getElementById("userInput").scrollIntoView(false);
        }

        firstBotMessage();

        // Retrieves the response
        function getHardResponse(userText) {
            let botResponse = getBotResponse(userText);
            let botHtml = '<p class="botText"><span>' + botResponse + '</span></p>';
            $("#chatbox").append(botHtml);

            document.getElementById("chat-bar-bottom").scrollIntoView(true);
        }

        //Gets the text text from the input box and processes it
        function getResponse() {
            let userText = $("#textInput").val();

            if (userText == "") {
                userText = "Hi!";
            }

            let userHtml = '<p class="userText"><span>' + userText + '</span></p>';

            $("#textInput").val("");
            $("#chatbox").append(userHtml);
            document.getElementById("chat-bar-bottom").scrollIntoView(true);

            setTimeout(() => {
                getHardResponse(userText);
            }, 1000)

        }

        // Handles sending text via button clicks
        function buttonSendText(sampleText) {
            let userHtml = '<p class="userText"><span>' + sampleText + '</span></p>';

            $("#textInput").val("");
            $("#chatbox").append(userHtml);
            document.getElementById("chat-bar-bottom").scrollIntoView(true);

            //Uncomment this if you want the bot to respond to this buttonSendText event
            // setTimeout(() => {
            //     getHardResponse(sampleText);
            // }, 1000)
        }

        function sendButton() {
            getResponse();
        }

        // Press enter to send a message
        $("#textInput").keypress(function (e) {
            if (e.which == 13) {
                getResponse();
            }
        });
    </script>

</body>

</html>