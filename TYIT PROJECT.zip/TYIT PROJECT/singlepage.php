<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car</title>
    <link rel="stylesheet" href="./websiteDesign/singlepage.css">
    <!--------css-------- bootstrap link ------------------>
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
       <!------ Font Awesome CDNJS -------->
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />

</head>

<body>
    <!-- Header Secton Started -->
    <header>
        <nav class="navbar navbar-expand-sm bg-body-tertiary" data-bs-theme="dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="./index.php"><img src="./image/newlogo.png"  alt=""
                        style="width: 220px;"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="./index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./ViewStock.php">View Stock</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./sellYourCar.php">Sell Your Car</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./aboutUs.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./ContactUs.php">Contact Us</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Header Secton Ended -->

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="./index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="./ViewStock.php">View Stock</a></li>
                <li class="breadcrumb-item active" aria-current="page"><a>Car</a></li>
            </ol>
        </nav>
    </header>
    <!-- Header Secton Started -->
    <section class="section">
        <?php
            include_once "./config/dbconnect.php";
            $Car_Id = $_GET['carId'];
            $sql="SELECT * FROM `car_stock`,`car_image` WHERE car_stock.car_id=car_image.car_id AND car_image.car_id='$Car_Id'";
            $result=$conn-> query($sql);
            if ($result-> num_rows > 0){
                while ($row=$result-> fetch_assoc()) {
        ?>
        <div class="container">
            <div class="_carShortDesc">
                <div class="d-flex justify-content-between">
                    <div class="outside">
                        <div class="carheading">
                            <h2 class="carh"><?=$row["year"]?>&nbsp;<?=$row["car_name"]?><span class="carhanother1">&nbsp;<?=$row["car_model"]?><small>&nbsp;<?=$row["transmission"]?></small></span></h2>
                        </div>
                        <div class="text-right">
                            <strong class="rate">
                                <span class="_1ntKF">₹&nbsp;<?=$row["price"]?></span>
                            </strong>
                        </div>

                        <div class="col middle">
                            <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas"
                                data-bs-target="#offcanvasTop" aria-controls="offcanvasTop">Show Interest</button>

                            <div class="offcanvas offcanvas-top" tabindex="-1" id="offcanvasTop"
                                aria-labelledby="offcanvasTopLabel">
                                <div class="offcanvas-header">
                                    <h4 class="offcanvas-title" id="offcanvasTopLabel">Owner will contact you as soon as possible!!!</h4>
                                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                        aria-label="Close"></button>
                                </div>
                                <div class="offcanvas-body">
                                    <form action="./execution/showInterestForm.php" method="POST" >
                                        <input type="text" name="car_name" value="<?=$row['car_name']?>" hidden>
                                        <input type="text" name="car_model" value="<?=$row['car_model']?>" hidden>
                                        <input type="text" name="year" value="<?=$row['year']?>" hidden>
                                        <input type="text" name="price" value="<?=$row['price']?>" hidden>    
                                        <h4>Personal Details:</h4>
                                        <div>
                                            <label><b>Full Name:&nbsp;&nbsp;&nbsp;</b></label>
                                            <input type="text" name="fname" placeholder="Enter Your Name" maxlength="40" required>
                                        </div>
                                        <br>
                                        <div>
                                            <label><b>Contact No.:&nbsp;&nbsp;&nbsp;</b></label>
                                            <input type="text" name="phone_no" placeholder="Enter Your Contact No." maxlength="10" required>
                                        </div>
                                        <br>
                                        <div>
                                            <button class="momBtn" type="submit" name="submit">Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="product row">
                <div class="fullpic col-md-8">
                    <img src="data:image/jpeg;charset=utf8;base64,<?=base64_encode($row["car_image"])?>" alt="" id="boxImg">
                </div>
                <div class="product-small row">
                    <img src="data:image/jpeg;charset=utf8;base64,<?=base64_encode($row["carimage_1"])?>" alt="" onclick="myFunction(this)" class="col-sm-4">
                    <img src="data:image/jpeg;charset=utf8;base64,<?=base64_encode($row["carimage_2"])?>" alt="" onclick="myFunction(this)" class="col-sm-4">
                    <img src="data:image/jpeg;charset=utf8;base64,<?=base64_encode($row["carimage_3"])?>" alt="" onclick="myFunction(this)" class="col-sm-4">
                    <img src="data:image/jpeg;charset=utf8;base64,<?=base64_encode($row["carimage_4"])?>" alt="" onclick="myFunction(this)" class="col-sm-4">
                    <img src="data:image/jpeg;charset=utf8;base64,<?=base64_encode($row["carimage_5"])?>" alt="" onclick="myFunction(this)" class="col-sm-4">
                    <img src="data:image/jpeg;charset=utf8;base64,<?=base64_encode($row["carimage_6"])?>" alt="" onclick="myFunction(this)" class="col-sm-4">
                    <img src="data:image/jpeg;charset=utf8;base64,<?=base64_encode($row["carimage_7"])?>" alt="" onclick="myFunction(this)" class="col-sm-4">
                    <img src="data:image/jpeg;charset=utf8;base64,<?=base64_encode($row["carimage_8"])?>" alt="" onclick="myFunction(this)" class="col-sm-4">
                </div>

            </div>
        </div>

        <div class="car-all-details">
            <div class="container">
                <div class="car-details row">
                    <div class="row">
                        <h1 class="clr">Car Details</h1>
                        <div class="col-9">
                            <h3 class="alien">Overview</h3>
                        </div>
                    <div class="col-4">
                        <ul class="list-group left">
                            <li class="list-group-item"><img src="./image/kmsDriven.png" alt="" style="width: 20px;">
                                <label for="">Kilometer Driven</label>
                                <h6><?=$row["kilo_driven"]?>&nbsp;km</h6>
                            </li>
                            <br>
                            <li class="list-group-item"><img src="./image/rigestered-in.png" alt="" style="width: 20px;">
                                <label for="">Registered-in</label>
                                <h6><?=$row["year"]?></h6>
                            </li><br>
                            <li class="list-group-item"><img src="./image/owner.png" alt="" style="width: 20px;">
                                <label for="">Owner</label>
                                <h6><?=$row["owner"]?></h6>
                            </li><br>
                        </ul>
                    </div>
                    <br>
                    <br>
                    <div class="col-4">
                        <ul class="list-group right">
                            <li class="list-group-item"><img src="./image/fuel-type.png" alt="" style="width: 20px;">
                                <label for="">Fuel Type</label>
                                <h6><?=$row["fuel_type"]?></h6>
                            </li><br>
                            <li class="list-group-item"><img src="./image/transimission.png" alt="" style="width: 20px;">
                                <label for="">Transmission</label>
                                <h6><?=$row["transmission"]?></h6>
                            </li><br>
                            <li class="list-group-item"><img src="./image/insurance.png" alt="" style="width: 20px;">
                                <label for="">Insurance</label>
                                <h6><?=$row["insurance"]?></h6>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
        <?php
                }
            }
        ?>
    </section>
    <!--------- footeer down  home page start here --------->
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <a href="index.php">
                        <img src="./image/weblogo-removebg-preview.png" alt="Sainath Motors" class="card-img-top"
                            style="width: 100px;">
                        <h1 class="card-title">Sainath Motors</h1>
                    </a>
                    <br>
                    <p class="card-text"> Your dream car may be purchased from Sainath Motors for the finest value and
                        quality. We have tens of thousands of happy consumers, and that number is rising daily. Join our
                        Sainath Motors family and take pleasure in the calm that comes with owning a flawless vehicle.
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3">
                    <h5 class="card-title">UseFul Link</h5>
                    <ul>
                        <li><a href="./index.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Home</span></a>
                        </li><br>
                        <li><a href="#Our Services"> <i class="fa-solid fa-angles-right"></i>
                                <span>Our Services</span></a>
                        </li><br>
                        <li> <a href="./ViewStock.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>View Stock</span></a>
                        </li><br>
                        <li><a href="./sellYourCar.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Sell Your Car</span></a>
                        </li><br>
                        <li><a href="./aboutUs.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>About Us</span></a>
                        </li><br>
                        <li> <a href="./ContactUs.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Contact Us</span></a>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Popular Cities</h5>
                    <ul style="margin-left: 30px;">
                        <li>Mumbai</li><br>
                        <li>Pune</li><br>
                        <li>Raigad</li><br>
                        <li>Mahad</li><br>
                        <li>Mangoan</li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Popular Brands</h5>
                    <ul style="margin-left: 30px;">
                        <li>Maruti Suzuki</li><br>
                        <li>Tata</li><br>
                        <li>Hyundai</li><br>
                        <li>Honda</li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Address / Contact Us</h5>
                    <p class="card-text"> <i class="fa-solid fa-location-dot"></i>
                        Shop No.10, Building
                        No.3, Phase -1 Neelam Nagar,
                        Mulund East Mumbai,
                        Maharashtra 400081
                        India</p>
                    <p class="card-text"><i class="fa-solid fa-phone"></i> +91 90904500112 </p>
                    <p class="card-text"><i class="fa-solid fa-envelope"></i> sainathmotors@gmail.com</p>
                </div>
            </div>
            <section id="copy-right">
                <div class="copy-right-sec"><i class="fa-solid fa-copyright"></i>
                    2023 <a href="index.php"> <span>Sainath Motors</span> </a>
                </div>
            </section>
        </div>
    </footer>
    <!--------- footeer down  home page end here --------->


    <script>
        function myFunction(smallImg) {
            var fullImg = document.getElementById("boxImg");
            fullImg.src = smallImg.src;
        }
    </script>


</body>

</html>