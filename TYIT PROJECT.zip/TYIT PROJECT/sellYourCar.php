<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sell Your Car</title>
    <link rel="stylesheet" href="./websiteDesign/sellYourCar.css">
    <!--------css-------- bootstrap link ------------------>
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <!---------js------- bootstrap link ------------------>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"></script>
    <!------ Font Awesome CDNJS -------->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <!-- textmonial -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
    <!-- chatbot  -->
    <link rel="stylesheet" href="./websiteDesign/chatbot.css">

    <style>
        html {
            scroll-behavior: smooth;
            font-family: Helvetica, sans-serif, Arial;
        }

        body {
            margin: 0 auto;
        }
    </style>

</head>

<body>
    <!-- Header Secton Started -->
    <header>
        <nav class="navbar navbar-expand-sm bg-body-tertiary" data-bs-theme="dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="./index.php"><img src="./image/newlogo.png"  alt=""
                        style="width: 220px;"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link active" href="./index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " aria-current="page" href="./ViewStock.php">View Stock</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="./aboutUs.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./ContactUs.php">Contact Us</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- Header Secton Ended -->

    <!-- CHAT BAR BLOCK -->
    <div class="chat-bar-collapsible">
        <button id="chat-button" type="button" class="collapsible">Need help?

        </button>

        <div class="content">
            <div class="full-chat-block">
                <!-- Message Container -->
                <div class="outer-container">
                    <div class="chat-container">
                        <!-- Messages -->
                        <div id="chatbox">
                            <h5 id="chat-timestamp"></h5>
                            <p id="botStarterMessage1" class="botText"><span>Loading...</span></p>
                            <p id="botStarterMessage2" class="botText"><span>Loading...</span></p>
                        </div>

                        <!-- User input box -->
                        <div class="chat-bar-input-block">
                            <div id="userInput">
                                <input id="textInput" class="input-box" type="text" name="msg"
                                    placeholder="Tap 'Enter' to send a message">
                                <p></p>
                            </div>

                            <div class="chat-bar-icons">
                                <i onclick="sendButton()" id="chat-icon" class="fa-solid fa-paper-plane"></i>


                            </div>
                        </div>

                        <div id="chat-bar-bottom">
                            <p></p>
                        </div>

                    </div>
                </div>

            </div>
        </div>

    </div>
    <!-- ---------------------------- -->
    <section class="section">
        <div class="container">
            <div class="firstView">
                <h1>Sell Your Car At The Best Price </h1>
                <div class="row ">
                    <div class="row align-items-center _1Box">
                        <li class="col">Sell From Your Home <img src="./image/right.png" alt="" class="_1BoxPic"></li>
                        <li class="col">Instant payment <img src="./image/right.png" alt="" class="_1BoxPic"></li>
                        <li class="col">RC Transfer <img src="./image/right.png" alt="" class="_1BoxPic"></li>
                    </div>

                    <div class="subBox"> 
                        <form id="regForm" action="./execution/insertSellYourCar.php" method="POST">
                            <h1 class="mom">Enter Your Car Details</h1>
                            <!-- One "tab" for each step in the form: -->
                            <div class="tab">
                                <label for="" class="question">Enter your Car's Brand Name</label>
                                <p><input type="text" placeholder="Eg: Maruti Suzuki" name="s_brand" maxlength="20" oninput="this.className = ''" autocomplete="on" list="Brands" required></p>
                                <datalist id="Brands">
                                    <option value="Maruti Suzuki">
                                    <option value="Hyundai">
                                    <option value="Tata">
                                    <option value="Volkswagen">
                                    <option value="Skoda">
                                    <option value="Honda">
                                    <option value="Kia">
                                    <option value="Renault">
                                    <option value="Mahindra">
                                </datalist>
                                
                                <label for="" class="question">Enter your Car's Name</label>
                                <p><input type="text" placeholder="Eg: Swift" name="s_carname" maxlength="40" oninput="this.className = ''" required ></p>
                                

                            </div>
                            <div class="tab">
                                <label for="" class="question">Enter the Purchasing Year of your Car</label>
                                <p><input type="number" placeholder="Eg: 2019" name="s_year" maxlength="10" oninput="this.className = ''" required ></p>
                                <span id="errornum"></span>
                                
                                <label for="" class="question">Enter your Car's Model Name</label>
                                <p><input placeholder="Eg: VXI" name="s_model" maxlength="20" oninput="this.className = ''" require></p>
                            </div>
                            <div class="tab">
                                <label for="" class="question">Enter your Car's Fuel type</label>
                                <p><input type="text" placeholder="Eg: Petrol" name="s_fuel" maxlength="10" oninput="this.className = ''" autocomplete="on" list="Fuels" required></p>
                                <span id="errortext"></span>
                                <datalist id="Fuels">
                                    <option value="Petrol">
                                    <option value="Diesel">
                                    <option value="CNG">
                                    <option value="Electric">
                                </datalist>
    
                                <label for="" class="question">Enter the Kms Driven</label>
                                <p><input type="number" placeholder="Eg: 10000" name="s_kiloDriven" maxlength="7" oninput="this.className = ''" required></p>
                                <span id="errornum"></span>
    
                                <label for="" class="question">Enter your Car's Transmission type</label>
                                <p><input type="text" placeholder="Eg: Manual" name="s_transmission" maxlength="10" oninput="this.className = ''" autocomplete="on" list="Transmissions" required></p>
                                <span id="errortext"></span>
                                <datalist id="Transmissions">
                                    <option value="Manual">
                                    <option value="Automatic">
                                </datalist>
                            </div>
                            <div class="tab">
                                <label for="" class="question">Full Name</label>
                                <p><input type="text" placeholder="Enter Your Full Name" name="s_name" maxlength="40" oninput="this.className = ''" required></p>
                                                               
                                <label for="" class="question">Contact Number</label>
                                <p><input type="number" placeholder="Enter Your Mobile Number" name="s_number" maxlength="10" oninput="this.className = ''" required></p>
                                <span id="errornum"></span>
                             
                                <button type="submit" name="submit" class="finbtn" >Submit</button>
                              
                            </div>
                            <div style="overflow:auto;">
                                <div style="float:right;">
                                <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                                    <button type="button" id="nextBtn" name="submit" onclick="nextPrev(1)">Next</button>
                                  
                                </div>
                            </div>

                            <!-- Circles which indicates the steps of the form: -->
                            <div style="text-align:center;margin-top:40px;">
                                <span class="step"></span>
                                <span class="step"></span>
                                <span class="step"></span>
                                <span class="step"></span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="secondView">
                <h1>HOW IT WORKS</h1>
                <div class="second row justify-content-between reveal">
                    <li class="col-md-4 card ">
                        <img src="./image/car-details.png" alt="" class="card-img-top"
                            style="height: 100px; width:100px;">
                        <h4 class="card-title">Enter your Car Details Online</h4>
                        <p class="card-text">Gone are the days of spending weeks to sell a car. Sell your car in minutes
                            from home.</p>
                    </li>

                    <li class="col-md-4 card">
                        <img src="./image/car-offer.png" alt="" class="card-img-top"
                            style="height: 100px; width:100px;">
                        <h4 class="card-title">Get a Final Offer, instantly!</h4>
                        <p class="card-text">The offer that we make based on the car details you fill will be final and
                            binding.
                        </p>
                    </li>

                    <li class="col-md-4 card">
                        <img src="./image/car-pickup.png" alt="" class="card-img-top"
                            style="height: 100px; width:100px;">
                        <h4 class="card-title">Doorstep Pickup</h4>
                        <p class="card-text">We will verify the car details at your home, pick up the car and transfer
                            the
                            amount.</p>
                    </li>

                </div>
            </div>

            <div class="thirdView">
                <h1>WHAT OUR CUSTOMER ARE SAYIING </h1>
                <div class="count">
                    <div class="row reveal">
                        <div class="value col">
                            <h5><strong>4.4</strong><br>Lakhs of Happy Customer </h5>
                        </div>
                        <div class="stars col reveal">
                            <span><i class="fa-solid fa-star"></i></span>
                            <span><i class="fa-solid fa-star"></i></span>
                            <span><i class="fa-solid fa-star"></i></span>
                            <span><i class="fa-solid fa-star"></i></span>
                            <span><i class="fa-solid fa-star-half-stroke"></i></span>
                            <br>
                            <strong class="_1lSox">RATING FROM OUR CUSTOMER</strong>
                        </div>
                    </div>


                    <section class="review section ">
                        <div class="container">
                            <div class="row reveal">
                                <div class="col-md-12">
                                    <div id="testimonial-slider" class="owl-carousel">
                                        <div class="testimonial">
                                            <div class="pic">
                                                <img src="./image/reviewsPic.gif">
                                            </div>
                                            <div class="testimonial-profile">
                                                <h3 class="title"> Satish Palkar</h3>
                                                <span class="post"></span>
                                            </div>
                                            <p class="description">
                                                "Best car sells in this sainath motors."
                                            </p>
                                        </div>
                                        <div class="testimonial">
                                            <div class="pic">
                                                <img src="./image/reviewsPic.gif">
                                            </div>
                                            <div class="testimonial-profile">
                                                <h3 class="title">Vivek Ramachandran</h3>
                                                <span class="post"></span>
                                            </div>
                                            <p class="description">
                                                "A very trustworthy place and good people to deal with. Happy to have
                                                them
                                                while
                                                dealing with Cars and managing its services!!!."
                                            </p>
                                        </div>
                                        <div class="testimonial">
                                            <div class="pic">
                                                <img src="./image/reviewsPic.gif">
                                            </div>
                                            <div class="testimonial-profile">
                                                <h3 class="title">Manish Vengurlekar</h3>
                                                <span class="post"></span>
                                            </div>
                                            <p class="description">
                                                "If u are looking for quality pre-owned car with peaceful transaction do
                                                visit
                                                once. Very nice cars and proper​ service.."
                                            </p>
                                        </div>
                                        <div class="testimonial">
                                            <div class="pic">
                                                <img src="./image/reviewsPic.gif">
                                            </div>
                                            <div class="testimonial-profile">
                                                <h3 class="title"> Abhijeet Jagdale</h3>
                                                <span class="post">Local Guide</span>
                                            </div>
                                            <p class="description">
                                                "Proffessional people. can deal with them no issues."
                                            </p>
                                        </div>
                                        <div class="testimonial">
                                            <div class="pic">
                                                <img src="./image/reviewsPic.gif">
                                            </div>
                                            <div class="testimonial-profile">
                                                <h3 class="title">YASHAWANT SANE</h3>
                                                <span class="post"></span>
                                            </div>
                                            <p class="description">
                                                "reliable car deal."
                                            </p>
                                        </div>
                                        <div class="testimonial">
                                            <div class="pic">
                                                <img src="./image/reviewsPic.gif">
                                            </div>
                                            <div class="testimonial-profile">
                                                <h3 class="title"> Ankur Sorathiya</h3>
                                                <span class="post"></span>
                                            </div>
                                            <p class="description">
                                                "V. Good."
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                </div>
            </div>


        </div>
    </section>

    <!--------- footeer down  home page start here --------->
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <a href="index.php">
                        <img src="./image/weblogo-removebg-preview.png" alt="Sainath Motors" class="card-img-top"
                            style="width: 100px;">
                        <h1 class="card-title">Sainath Motors</h1>
                    </a>
                    <br>
                    <p class="card-text"> Your dream car may be purchased from Sainath Motors for the finest value and
                        quality. We have tens of thousands of happy consumers, and that number is rising daily. Join our
                        Sainath Motors family and take pleasure in the calm that comes with owning a flawless vehicle.
                    </p>
                </div>
            </div>
            <div class="row ">
                <div class="col-sm-3">
                    <h5 class="card-title">UseFul Link</h5>
                    <ul>
                        <li><a href="index.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Home</span></a>
                        </li><br>
                        <li><a href="#Our Services"> <i class="fa-solid fa-angles-right"></i>
                                <span>Our Services</span></a>
                        </li><br>
                        <li> <a href="ViewStock.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>View Stock</span></a>
                        </li><br>
                        <li><a href="sellYourCar.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Sell Your Car</span></a>
                        </li><br>
                        <li><a href="aboutUs.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>About Us</span></a>
                        </li><br>
                        <li> <a href="ContactUs.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Contact Us</span></a>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Popular Cities</h5>
                    <ul style="margin-left: 28px;">
                        <li>Mumbai</li><br>
                        <li>Pune</li><br>
                        <li>Raigad</li><br>
                        <li>Mahad</li><br>
                        <li>Mangoan</li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Popular Brands</h5>
                    <ul style="margin-left: 28px;">
                        <li>Maruti Suzuki</li><br>
                        <li>Tata</li><br>
                        <li>Hyundai</li><br>
                        <li>Honda</li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Address / Contact Us</h5>
                    <p class="card-text"> <i class="fa-solid fa-location-dot"></i>
                        Shop No.10, Building
                        No.3, Phase -1 Neelam Nagar,
                        Mulund East Mumbai,
                        Maharashtra 400081
                        India</p>
                    <p class="card-text"><i class="fa-solid fa-phone"></i> +91 90904500112 </p>
                    <p class="card-text"><i class="fa-solid fa-envelope"></i> sainathmotors@gmail.com</p>
                </div>
            </div>
            <section id="copy-right">
                <div class="copy-right-sec"><i class="fa-solid fa-copyright"></i>
                    2023 <a href="index.php"> <span>Sainath Motors</span> </a>
                </div>
            </section>
        </div>
    </footer>
    <!--------- footeer down  home page end here --------->
    <script src="./logic/mainFile.js"></script>

    <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
    <script>
        $(document).ready(function () {
            $("#testimonial-slider").owlCarousel({
                items: 2,
                itemsDesktop: [1000, 2],
                itemsDesktopSmall: [979, 2],
                itemsTablet: [768, 1],
                pagination: false,
                navigation: true,
                navigationText: ["", ""],
                autoPlay: true
            });
        });
    </script>
   <!-- chatbot -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
    <script>
        // Collapsible
        var coll = document.getElementsByClassName("collapsible");

        for (let i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function () {
                this.classList.toggle("active");

                var content = this.nextElementSibling;

                if (content.style.maxHeight) {
                    content.style.maxHeight = null;
                } else {
                    content.style.maxHeight = content.scrollHeight + "px";
                }

            });
        }

        function getTime() {
            let today = new Date();
            hours = today.getHours();
            minutes = today.getMinutes();

            if (hours < 10) {
                hours = "0" + hours;
            }

            if (minutes < 10) {
                minutes = "0" + minutes;
            }

            let time = hours + ":" + minutes;
            return time;
        }

        // Gets the first message
        function firstBotMessage() {
            let firstMessage = "Hello there! I'm Autoamy."
            let secondMessage = "What can I help you with?<br>(Enter the appropriate task/service NUMBER that you intend to avail.) <br>1. View available stock <br>2. Ask for Insurance Guidance <br>3. Ask for Finance Guidance <br>4. RTO Transfer <br>5. Sell your Car <br>6. Give Feedback"
            document.getElementById("botStarterMessage1").innerHTML = '<p class="botText"><span>' + firstMessage + '</span></p>';
            document.getElementById("botStarterMessage2").innerHTML = '<p class="botText"><span>' + secondMessage + '</span></p>';

            let time = getTime();

            $("#chat-timestamp").append(time);
            document.getElementById("userInput").scrollIntoView(false);
        }

        firstBotMessage();

        // Retrieves the response
        function getHardResponse(userText) {
            let botResponse = getBotResponse(userText);
            let botHtml = '<p class="botText"><span>' + botResponse + '</span></p>';
            $("#chatbox").append(botHtml);

            document.getElementById("chat-bar-bottom").scrollIntoView(true);
        }

        //Gets the text text from the input box and processes it
        function getResponse() {
            let userText = $("#textInput").val();

            if (userText == "") {
                userText = "Hi!";
            }

            let userHtml = '<p class="userText"><span>' + userText + '</span></p>';

            $("#textInput").val("");
            $("#chatbox").append(userHtml);
            document.getElementById("chat-bar-bottom").scrollIntoView(true);

            setTimeout(() => {
                getHardResponse(userText);
            }, 1000)

        }

        // Handles sending text via button clicks
        function buttonSendText(sampleText) {
            let userHtml = '<p class="userText"><span>' + sampleText + '</span></p>';

            $("#textInput").val("");
            $("#chatbox").append(userHtml);
            document.getElementById("chat-bar-bottom").scrollIntoView(true);

            //Uncomment this if you want the bot to respond to this buttonSendText event
            // setTimeout(() => {
            //     getHardResponse(sampleText);
            // }, 1000)
        }

        function sendButton() {
            getResponse();
        }

        // Press enter to send a message
        $("#textInput").keypress(function (e) {
            if (e.which == 13) {
                getResponse();
            }
        });
    </script>




<script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    // document.getElementById("nextBtn") = "Submit";
    document.getElementById("nextBtn").innerHTML = "Next";
  } else {
    
  }
  //... and run a function that will display the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}
</script>
<script>
    function nextBtn() {
		var error = document.getElementById("errornum")
		if (isNaN(document.getElementById("number").value))
		{
			
			// Changing content and color of content
			error.textContent = "Please enter a valid number"
			error.style.color = "red"
		} else {
			error.textContent = ""
		}
	}
</script>
    

</body>

</html>