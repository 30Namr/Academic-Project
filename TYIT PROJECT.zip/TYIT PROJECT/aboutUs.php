<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="./websiteDesign/aboutUs.css">
    <!--------css-------- bootstrap link ------------------>
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <!---------js------- bootstrap link ------------------>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!------ Font Awesome CDNJS -------->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <!-- chatbot  -->
    <link rel="stylesheet" href="./websiteDesign/chatbot.css">

    <style>
        html {
            scroll-behavior: smooth;
            font-family: Helvetica, sans-serif, Arial;
        }

        body {
            margin: 0 auto;
        }
    </style>

</head>

<body>
    <!-- Header Secton Started -->
    <header>
        <nav class="navbar navbar-expand-sm bg-body-tertiary" data-bs-theme="dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="./index.php"><img src="./image/newlogo.png" alt=""
                        style="width: 220px;"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="./index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./ViewStock.php">View Stock</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./sellYourCar.php">Sell Your Car</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="./ContactUs.php">Contact Us</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- Header Secton Ended -->


    <!-- CHAT BAR BLOCK -->
    <div class="chat-bar-collapsible">
        <button id="chat-button" type="button" class="collapsible">Need help?
           
        </button>

        <div class="content">
            <div class="full-chat-block">
                <!-- Message Container -->
                <div class="outer-container">
                    <div class="chat-container">
                        <!-- Messages -->
                        <div id="chatbox">
                            <h5 id="chat-timestamp"></h5>
                            <p id="botStarterMessage1" class="botText"><span>Loading...</span></p>
                            <p id="botStarterMessage2" class="botText"><span>Loading...</span></p>
                        </div>

                        <!-- User input box -->
                        <div class="chat-bar-input-block">
                            <div id="userInput">
                                <input id="textInput" class="input-box" type="text" name="msg"
                                    placeholder="Tap 'Enter' to send a message">
                                <p></p>
                            </div>

                            <div class="chat-bar-icons">
                                <i onclick="sendButton()" id="chat-icon" class="fa-solid fa-paper-plane"></i>


                            </div>
                        </div>

                        <div id="chat-bar-bottom">
                            <p></p>
                        </div>

                    </div>
                </div>

            </div>
        </div>

    </div>

    <!-- ---------------------------------- -->
    <section>
        <div class="container text-center ">
            <h1 class="">Welcome To <span>Sainath Motors</span> </h1>

            <div class="card ">
                <img src="./image/aboutusimg.jpeg" alt="About Us " class="card-img-top"
                    style="width: 1334px; height: 550px;">
            </div>
            <div class=" About">
                <div class="row">
                    <h3> How and when established</h3>
                    <p class="para">The year 1997 saw the founding of Sainath Motors by brothers Sandeep and
                        Mayuresh
                        Chudnaik.
                        Their objective when starting this company was to offer a perfect used car to everyone who
                        couldn't
                        afford to buy a new one.</p>
                </div><br>
                <div class="row">
                    <h3>Company details</h3>
                    <p class="para">Their showroom was founded in and is still located in Mulund.
                        The showroom is situated at Shop No.10, Building, No.3, Phase -1,
                        Neelam Nagar, Mulund East, Mumbai, Maharashtra 400081.
                        Here, one can choose the ideal used car for them from a broad collection
                        based on their requirements and budget range.</p>
                </div>
                <br><br>
                <div class="row">
                    <h3>Mission</h3>
                    <p class="para">Our goal is to completely transform the way used automobiles are purchased
                        and sold
                        in Maharashtra.And since 1997, we've carried this objective in mind.
                        Thanks to constant innovation and the development of valuable relationships with a large
                        number of individuals we've come a long way since then.
                        We wish to continue helping customers with their issues and making their lives easier and
                        more valuable..</p>
                </div><br>
                <div class="row">
                    <h3>Vision</h3>
                    <p class="para">Our vision is to keep our customers happy and
                        satisfied with te cars and services we provide to them
                        In order to maintain our clients' satisfaction with our
                        services, we work hard to establish trust with them
                        We aim to establish our business across multiple states and add more and more happy
                        customers
                        along the way of our progress..</p>
                </div>
            </div>


        </div>
    </section>
    <!--------- footeer down  home page start here --------->
    <footer id="footer">
        <div class="container reveal">
            <div class="row">
                <div class="col-md-6">
                    <a href="index.php">
                        <img src="./image/weblogo-removebg-preview.png" alt="Sainath Motors" class="card-img-top"
                            style="width: 100px;">
                        <h1 class="card-title">Sainath Motors</h1>
                    </a>
                    <br>
                    <p class="card-text"> Your dream car may be purchased from Sainath Motors for the finest value and
                        quality. We have tens of thousands of happy consumers, and that number is rising daily. Join our
                        Sainath Motors family and take pleasure in the calm that comes with owning a flawless vehicle.
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3">
                    <h5 class="card-title">UseFul Link</h5>
                    <ul>
                        <li><a href="index.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Home</span></a>
                        </li><br>
                        <li><a href="#Our Services"> <i class="fa-solid fa-angles-right"></i>
                                <span>Our Services</span></a>
                        </li><br>
                        <li> <a href="ViewStock.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>View Stock</span></a>
                        </li><br>
                        <li><a href="sellYourCar.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Sell Your Car</span></a>
                        </li><br>
                        <li><a href="aboutUs.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>About Us</span></a>
                        </li><br>
                        <li> <a href="ContactUs.php"> <i class="fa-solid fa-angles-right"></i>
                                <span>Contact Us</span></a>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Popular Cities</h5>
                    <ul style="margin-left: 25px;">
                        <li>Mumbai</li><br>
                        <li>Pune</li><br>
                        <li>Raigad</li><br>
                        <li>Mahad</li><br>
                        <li>Mangoan</li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Popular Brands</h5>
                    <ul style="margin-left: 25px;">
                        <li>Maruti Suzuki</li><br>
                        <li>Tata</li><br>
                        <li>Hyundai</li><br>
                        <li>Honda</li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5 class="card-title">Address / Contact Us</h5>
                    <p class="card-text"> <i class="fa-solid fa-location-dot"></i>
                        Shop No.10, Building
                        No.3, Phase -1 Neelam Nagar,
                        Mulund East Mumbai,
                        Maharashtra 400081
                        India</p>
                    <p class="card-text"><i class="fa-solid fa-phone"></i> +91 90904500112 </p>
                    <p class="card-text"><i class="fa-solid fa-envelope"></i> sainathmotors@gmail.com</p>
                </div>
            </div>
            <section id="copy-right">
                <div class="copy-right-sec"><i class="fa-solid fa-copyright"></i>
                    2023 <a href="index.php"> <span>Sainath Motors</span> </a>
                </div>
            </section>
        </div>
    </footer>
    <!--------- footeer down  home page end here --------->

    <script src="./logic/mainFile.js"></script>

    <!-- chatbot -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        // Collapsible
        var coll = document.getElementsByClassName("collapsible");

        for (let i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function () {
                this.classList.toggle("active");

                var content = this.nextElementSibling;

                if (content.style.maxHeight) {
                    content.style.maxHeight = null;
                } else {
                    content.style.maxHeight = content.scrollHeight + "px";
                }

            });
        }

        function getTime() {
            let today = new Date();
            hours = today.getHours();
            minutes = today.getMinutes();

            if (hours < 10) {
                hours = "0" + hours;
            }

            if (minutes < 10) {
                minutes = "0" + minutes;
            }

            let time = hours + ":" + minutes;
            return time;
        }

        // Gets the first message
        function firstBotMessage() {
            let firstMessage = "Hello there! I'm Autoamy."
            let secondMessage = "What can I help you with?<br>(Enter the appropriate task/service NUMBER that you intend to avail.) <br>1. View available stock <br>2. Ask for Insurance Guidance <br>3. Ask for Finance Guidance <br>4. RTO Transfer <br>5. Sell your Car <br>6. Give Feedback"
            document.getElementById("botStarterMessage1").innerHTML = '<p class="botText"><span>' + firstMessage + '</span></p>';
            document.getElementById("botStarterMessage2").innerHTML = '<p class="botText"><span>' + secondMessage + '</span></p>';

            let time = getTime();

            $("#chat-timestamp").append(time);
            document.getElementById("userInput").scrollIntoView(false);
        }

        firstBotMessage();

        // Retrieves the response
        function getHardResponse(userText) {
            let botResponse = getBotResponse(userText);
            let botHtml = '<p class="botText"><span>' + botResponse + '</span></p>';
            $("#chatbox").append(botHtml);

            document.getElementById("chat-bar-bottom").scrollIntoView(true);
        }

        //Gets the text text from the input box and processes it
        function getResponse() {
            let userText = $("#textInput").val();

            if (userText == "") {
                userText = "Hi!";
            }

            let userHtml = '<p class="userText"><span>' + userText + '</span></p>';

            $("#textInput").val("");
            $("#chatbox").append(userHtml);
            document.getElementById("chat-bar-bottom").scrollIntoView(true);

            setTimeout(() => {
                getHardResponse(userText);
            }, 1000)

        }

        // Handles sending text via button clicks
        function buttonSendText(sampleText) {
            let userHtml = '<p class="userText"><span>' + sampleText + '</span></p>';

            $("#textInput").val("");
            $("#chatbox").append(userHtml);
            document.getElementById("chat-bar-bottom").scrollIntoView(true);

            //Uncomment this if you want the bot to respond to this buttonSendText event
            // setTimeout(() => {
            //     getHardResponse(sampleText);
            // }, 1000)
        }

        function sendButton() {
            getResponse();
        }

        // Press enter to send a message
        $("#textInput").keypress(function (e) {
            if (e.which == 13) {
                getResponse();
            }
        });
    </script>
</body>

</html>